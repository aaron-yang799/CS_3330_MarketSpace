import static org.junit.asser.*
import org.junit.after




public class JU_TESTS 