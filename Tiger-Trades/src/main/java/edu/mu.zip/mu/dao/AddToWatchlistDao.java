package edu.mu.dao;

public class AddToWatchlistDao {
	
}
